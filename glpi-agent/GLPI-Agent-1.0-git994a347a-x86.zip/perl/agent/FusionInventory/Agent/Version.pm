package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-git994a347a";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Mon Jun  7 10:11:52 2021 UTC",
    "Built with Strawberry Perl 5.32.1",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
