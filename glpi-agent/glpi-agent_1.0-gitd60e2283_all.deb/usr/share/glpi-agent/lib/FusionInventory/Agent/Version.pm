package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-gitd60e2283";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2021-06-04 20:30"
];

1;

