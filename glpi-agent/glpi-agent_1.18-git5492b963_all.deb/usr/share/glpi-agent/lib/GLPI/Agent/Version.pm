package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.18-git5492b963";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-04-22 11:31"
];

1;

