package
        setup;

use strict;
use warnings;
use parent qw(Exporter);

use English qw(-no_match_vars);
use UNIVERSAL::require;
use File::Basename qw(dirname);

our @EXPORT = ('%setup');

our %setup = (
    datadir => "/usr/share/glpi-agent",
    libdir  => "/usr/share/glpi-agent/lib",
    vardir  => "/var/lib/glpi-agent",
);

1;
