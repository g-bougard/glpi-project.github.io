package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-git01fbb4c8";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2021-06-07 15:54"
];

1;

