package
        setup;

use strict;
use warnings;
use parent qw(Exporter);

our @EXPORT = ('%setup');

our %setup = (
    datadir => "/usr/share/glpi-agent",
    libdir  => "/usr/share/glpi-agent/lib",
    vardir  => "/var/lib/glpi-agent",
);

1;
