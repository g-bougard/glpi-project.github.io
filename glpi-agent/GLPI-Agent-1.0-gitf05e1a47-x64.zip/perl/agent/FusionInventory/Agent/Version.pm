package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-gitf05e1a47";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Fri Jun  4 16:02:59 2021 UTC",
    "Built with Strawberry Perl 5.32.1",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
