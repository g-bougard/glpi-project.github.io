package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-gitf05e1a47";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2021-06-04 15:55"
];

1;

