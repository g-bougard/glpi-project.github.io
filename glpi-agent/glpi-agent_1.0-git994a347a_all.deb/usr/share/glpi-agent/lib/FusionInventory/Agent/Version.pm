package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-git994a347a";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2021-06-07 10:04"
];

1;

