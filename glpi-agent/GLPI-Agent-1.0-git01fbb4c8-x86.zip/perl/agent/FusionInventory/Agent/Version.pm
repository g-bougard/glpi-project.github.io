package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.0-git01fbb4c8";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Mon Jun  7 16:00:35 2021 UTC",
    "Built with Strawberry Perl 5.32.1",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
